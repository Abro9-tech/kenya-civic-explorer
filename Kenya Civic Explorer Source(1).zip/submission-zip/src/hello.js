export default function getMessage() {
  return 'Welcome to your Vanilla JavaScript site, built with minimal dependencies.';
}
